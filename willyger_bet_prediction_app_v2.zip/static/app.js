async function fetchToday() {
  const container = document.getElementById('matches');
  container.innerHTML = 'Loading today\'s matches...';
  try {
    const r = await fetch('/api/today');
    const j = await r.json();
    if (j.error) { container.innerText = 'Error: ' + j.error; return; }
    const matches = j.matches || [];
    if (!matches.length) { container.innerText = 'No matches found for today.'; return; }
    container.innerHTML = '';
    for (const m of matches) {
      const card = document.createElement('div');
      card.className = 'p-3 bg-gray-50 border rounded flex items-center justify-between';
      const left = document.createElement('div');
      left.innerHTML = `<div class="font-semibold">${m.homeTeam.name} vs ${m.awayTeam.name}</div><div class="text-xs text-gray-500">${m.competition} • ${new Date(m.utcDate).toLocaleString()}</div>`;
      const right = document.createElement('div');
      const btn = document.createElement('button');
      btn.className = 'bg-blue-700 text-white px-3 py-1 rounded font-semibold';
      btn.innerText = 'Predict';
      btn.onclick = async () => {
        btn.disabled = true; btn.innerText = 'Predicting...';
        try {
          const p = await fetch('/api/predict', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({home: m.homeTeam.id, away: m.awayTeam.id})});
          const res = await p.json();
          btn.disabled = false; btn.innerText = 'Predict';
          if (res.error) { alert(res.error); return; }
          const modal = document.createElement('div');
          modal.className = 'fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4';
          modal.innerHTML = `<div class="bg-white p-4 rounded max-w-md w-full text-gray-900">
            <h3 class="font-semibold mb-2">${res.home_stats.team} vs ${res.away_stats.team}</h3>
            <div class="grid grid-cols-3 gap-2 mb-3">
              <div class="text-center p-2 bg-blue-50 rounded"><div class="text-xs">Home</div><div class="font-bold">${(res.prediction['Home Win']*100).toFixed(1)}%</div></div>
              <div class="text-center p-2 bg-blue-50 rounded"><div class="text-xs">Draw</div><div class="font-bold">${(res.prediction['Draw']*100).toFixed(1)}%</div></div>
              <div class="text-center p-2 bg-blue-50 rounded"><div class="text-xs">Away</div><div class="font-bold">${(res.prediction['Away Win']*100).toFixed(1)}%</div></div>
            </div>
            <div class="text-sm mb-2"><strong>Home last:</strong> ${res.home_stats.form.join(', ') || 'N/A'}</div>
            <div class="text-sm mb-2"><strong>Away last:</strong> ${res.away_stats.form.join(', ') || 'N/A'}</div>
            <div class="text-right"><button id="closeBtn" class="accent-gold px-3 py-1 rounded">Close</button></div>
          </div>`;
          document.body.appendChild(modal);
          document.getElementById('closeBtn').onclick = () => modal.remove();
        } catch (e) {
          btn.disabled = false; btn.innerText = 'Predict';
          alert('Error predicting: ' + e.message);
        }
      };
      right.appendChild(btn);
      card.appendChild(left); card.appendChild(right);
      container.appendChild(card);
    }
  } catch (e) {
    document.getElementById('matches').innerText = 'Failed to load today\'s matches: ' + e.message;
  }
}

async function loadModelInfo() {
  try {
    const r = await fetch('/api/model-stats');
    const j = await r.json();
    document.getElementById('modelInfo').innerText = `Accuracy: ${ (j.accuracy*100).toFixed(1) }% • Last trained: ${j.last_trained}`;
  } catch (e) {
    document.getElementById('modelInfo').innerText = 'Model info unavailable';
  }
}

document.getElementById('refreshBtn').addEventListener('click', fetchToday);
window.addEventListener('DOMContentLoaded', () => { fetchToday(); loadModelInfo(); });
