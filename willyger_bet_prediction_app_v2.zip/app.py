
from flask import Flask, request, jsonify, send_from_directory
import os, requests
from datetime import datetime
app = Flask(__name__, static_folder='static', static_url_path='/static')

# ----- Configuration -----
API_KEY = os.environ.get('FOOTBALL_DATA_KEY', 'fee93893acd2427c963c5135bbb69596')
API_BASE = 'https://api.football-data.org/v2'
HEADERS = {'X-Auth-Token': API_KEY}

CACHE = {}

def api_get(path, params=None):
    url = API_BASE.rstrip('/') + '/' + path.lstrip('/')
    r = requests.get(url, headers=HEADERS, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/today')
def api_today():
    today = datetime.utcnow().date()
    date_str = today.isoformat()
    cache_key = f"today:{date_str}"
    if cache_key in CACHE:
        return jsonify(CACHE[cache_key])
    params = {'dateFrom': date_str, 'dateTo': date_str}
    try:
        data = api_get('matches', params=params)
        matches = data.get('matches', [])
    except Exception as e:
        return jsonify({'error': 'Failed to fetch matches', 'detail': str(e)}), 500
    out = []
    for m in matches:
        out.append({
            'id': m.get('id'),
            'utcDate': m.get('utcDate'),
            'competition': m.get('competition',{}).get('name'),
            'homeTeam': {'id': m.get('homeTeam',{}).get('id'), 'name': m.get('homeTeam',{}).get('name')},
            'awayTeam': {'id': m.get('awayTeam',{}).get('id'), 'name': m.get('awayTeam',{}).get('name')},
            'status': m.get('status')
        })
    res = {'matches': out}
    CACHE[cache_key] = res
    return jsonify(res)

def get_last_matches(team_id, limit=5):
    cache_key = f"team_matches:{team_id}:{limit}"
    if cache_key in CACHE:
        return CACHE[cache_key]
    try:
        params = {'status': 'FINISHED', 'limit': limit}
        data = api_get(f'teams/{team_id}/matches', params=params)
        matches = data.get('matches', [])
    except Exception:
        matches = []
    CACHE[cache_key] = matches
    return matches

def compute_form_and_goals(matches, team_id):
    if not matches:
        return {'form_points': 0.0, 'avg_gf': 1.2, 'avg_ga': 1.2, 'results': []}
    pts = 0
    gf = []
    ga = []
    results = []
    for m in matches:
        score = m.get('score',{}).get('fullTime',{})
        home = m.get('homeTeam',{}).get('id')
        away = m.get('awayTeam',{}).get('id')
        home_goals = score.get('homeTeam')
        away_goals = score.get('awayTeam')
        if home_goals is None or away_goals is None:
            continue
        if team_id == home:
            gf.append(home_goals); ga.append(away_goals)
            if home_goals > away_goals:
                pts += 3; results.append('W')
            elif home_goals == away_goals:
                pts += 1; results.append('D')
            else:
                results.append('L')
        else:
            gf.append(away_goals); ga.append(home_goals)
            if away_goals > home_goals:
                pts += 3; results.append('W')
            elif away_goals == home_goals:
                pts += 1; results.append('D')
            else:
                results.append('L')
    avg_gf = sum(gf)/len(gf) if gf else 1.2
    avg_ga = sum(ga)/len(ga) if ga else 1.2
    return {'form_points': pts, 'avg_gf': avg_gf, 'avg_ga': avg_ga, 'results': results}

@app.route('/api/predict', methods=['POST'])
def api_predict():
    data = request.json or {}
    home = data.get('home') or (data.get('homeTeam') and data.get('homeTeam').get('id'))
    away = data.get('away') or (data.get('awayTeam') and data.get('awayTeam').get('id'))
    if isinstance(home, dict): home = home.get('id')
    if isinstance(away, dict): away = away.get('id')
    if not home or not away:
        return jsonify({'error': 'Please provide home and away team ids'}), 400
    home_matches = get_last_matches(home, limit=5)
    away_matches = get_last_matches(away, limit=5)
    hs = compute_form_and_goals(home_matches, home)
    as_ = compute_form_and_goals(away_matches, away)
    home_adv = 0.06
    hf = min(1.0, hs['form_points'] / 15.0)
    af = min(1.0, as_['form_points'] / 15.0)
    gf_diff = hs['avg_gf'] - as_['avg_gf']
    h_base = 0.5 + home_adv + 0.2*(hf - af) + 0.1*gf_diff
    h_prob = max(0.05, min(0.9, h_base))
    a_prob = max(0.03, min(0.9, 1 - h_prob - 0.15))
    d_prob = max(0.02, 1 - h_prob - a_prob)
    total = h_prob + d_prob + a_prob
    res = {'Home Win': h_prob/total, 'Draw': d_prob/total, 'Away Win': a_prob/total}
    meta = {'source': 'football-data.org', 'generated_at': datetime.utcnow().isoformat() + 'Z'}
    try:
        home_info = api_get(f'teams/{home}')
        away_info = api_get(f'teams/{away}')
    except Exception:
        home_info = {'id': home, 'name': str(home)}
        away_info = {'id': away, 'name': str(away)}
    return jsonify({
        'prediction': res,
        'home_stats': {'avg_gf': hs['avg_gf'], 'avg_ga': hs['avg_ga'], 'form': hs['results'], 'team': home_info.get('name', str(home))},
        'away_stats': {'avg_gf': as_['avg_gf'], 'avg_ga': as_['avg_ga'], 'form': as_['results'], 'team': away_info.get('name', str(away))},
        'meta': meta
    })

@app.route('/api/model-stats')
def api_model_stats():
    return jsonify({'accuracy': 0.65, 'last_trained': '2025-10-17'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
